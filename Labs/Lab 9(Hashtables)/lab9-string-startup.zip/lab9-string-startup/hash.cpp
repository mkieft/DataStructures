// CPP program to implement hashing with chaining
#include<iostream>
#include "hash.hpp"

using namespace std;

node* HashTable::createNode(string key, node* next)
{
    node* nw = new node;
    nw->key = key;
    nw->next = next;
    return nw;
}

HashTable::HashTable(int bsize)
{

}

//function to calculate hash function
unsigned int HashTable::hashFunction(string key)
{
    unsigned int hash = 0;

    return hash ;
}

//function to search
node* HashTable::searchItem(string key)
{
    return nullptr;
}

//function to insert
bool HashTable::insertItem(string key)
{
    return false;
}

// function to delete
bool HashTable::deleteItem(string key)
{
    return false;
}

// function to display hash table
void HashTable::printTable()
{
    for (int i = 0; i < tableSize; i++) {
        cout << i <<"|| ";
        node* temp = table[i];
        while(temp)
        {
            cout<< temp->key;
            if(temp->next!=nullptr)
            {
                cout<<"-->";
            }
            temp = temp->next;
        }
        cout<<endl;

    }
}
